#if defined(LANG_LITHUANIAN)            //Lithuanian
   const unsigned char TestRunning[] MEM_TEXT = "bandymai..."; //"Testing...";
   const unsigned char BatWeak[] MEM_TEXT = "silpnas"; //"weak";
   const unsigned char BatEmpty[] MEM_TEXT = "dykas!"; //"empty!"
   const unsigned char TestFailed2[] MEM_TEXT = "sugadintas "; //"damaged ";
   const unsigned char Bauteil[] MEM_TEXT = "dalis"; //"part";
//   const unsigned char Diode[] MEM_TEXT = "Diode: ";
   const unsigned char Triac[] MEM_TEXT = "simistorinis"; //"Triac";
   const unsigned char Thyristor[] MEM_TEXT = "Tiristorinis"; //"Thyristor";
   const unsigned char Unknown[] MEM_TEXT = " nezinomas"; //" unknown";
   const unsigned char TestFailed1[] MEM_TEXT = "Nezinomas, arba"; //"No, unknown, or";
   const unsigned char OrBroken[] MEM_TEXT = "arba sugadintas "; //"or damamaged";
   const unsigned char TestTimedOut[] MEM_TEXT = "laikas!"; //"Timeout!";
   #define Cathode_char 'C'
 #ifdef WITH_SELFTEST
   const unsigned char SELFTEST[] MEM_TEXT = "Selftest rezimas.."; //"Selftest mode..";
   const unsigned char RELPROBE[] MEM_TEXT = "izoliuoti zonda"; //"isolate Probe!";
   const unsigned char ATE[] MEM_TEXT = "banymo pabaigoje"; //"Test End";
 #endif
#endif

